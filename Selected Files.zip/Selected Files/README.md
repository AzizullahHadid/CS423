# OpenMRS Core — Selected Java Files

Source repository: https://github.com/openmrs/openmrs-core

15 Java files were randomly sampled from the project, split into three
size categories (5 files each, based on line count):

- `small/` — files with ≤ 50 lines
- `medium/` — files with 51–99 lines
- `large/` — files with ≥ 100 lines

## small/

| File | Description |
|---|---|
| `CustomDatatypeUtilTest.java` | JUnit test class for `CustomDatatypeUtil`, verifying deserialization of simple configuration strings. |
| `LocationEditor.java` | A Spring `PropertyEditor` that converts a `Location` object to/from its string (or UUID) representation for HTML forms. |
| `OpenmrsCharacterEscapes.java` | Extends Jackson's `CharacterEscapes` to escape HTML/script characters when serializing objects to JSON. |
| `OpenmrsThreadPoolHolder.java` | A small utility class that exposes a single static cached `ExecutorService` used for background thread pooling. |
| `PatientSaveHandler.java` | A `RequiredDataHandler` that runs automatically when a `Patient` is saved, setting required data before persistence. |

## medium/

| File | Description |
|---|---|
| `ConnectionPoolConfigTest.java` | Tests the c3p0 connection pool configuration used by Hibernate's `SessionFactory`. |
| `HL7SourceValidatorTest.java` | JUnit tests for `HL7SourceValidator`, checking validation errors on `HL7Source` objects. |
| `OrderSetDAO.java` | DAO interface defining database access methods for `OrderSet`, used internally by `OrderSetService`. |
| `PersonVoidHandler.java` | A void handler that sets `personVoided*` fields on a `Person` object when it is voided, distinct from the generic void handler. |
| `StartupErrorFilterTest.java` | Tests `StartupErrorFilter`, the servlet filter that intercepts requests when OpenMRS fails to start correctly. |

## large/

| File | Description |
|---|---|
| `BaseAttribute.java` | Abstract JPA mapped superclass for custom attribute entities, providing common attribute-type and value-reference behavior. |
| `ConceptReferenceTermValidatorTest.java` | JUnit tests validating `ConceptReferenceTerm` objects, including checks on concept map types. |
| `HibernateCohortDAO.java` | Hibernate-based DAO implementation for `Cohort` and `CohortMembership` persistence and queries. |
| `VisitSearchCriteriaBuilder.java` | Builder class used to construct `VisitSearchCriteria` objects for flexible querying of patient visits. |
| `WebUtilTest.java` | JUnit tests for the `WebUtil` helper class used across the OpenMRS web layer. |
